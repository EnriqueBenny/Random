from renown_calculation.director import Director

director = Director()
director.start()